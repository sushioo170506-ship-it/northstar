双击report.html在浏览器中演示；方向键/空格翻页，F全屏。report.pptx可在PowerPoint或WPS中编辑。本包为私有离线交付，不包含公开托管链接。
