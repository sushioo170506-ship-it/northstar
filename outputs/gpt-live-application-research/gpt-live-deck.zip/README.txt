双击 gpt-live-deck.html 在浏览器中演示；方向键/空格翻页，F全屏。gpt-live-deck.pptx 可在 PowerPoint/WPS 中编辑。
